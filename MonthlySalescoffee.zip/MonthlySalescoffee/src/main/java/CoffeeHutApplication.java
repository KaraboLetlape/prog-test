
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class RunAplicationJava {
    
}


public static void main(String[] args) {
Scanner input = new Scanner(System.in);

// Single arrays
String[] cities = {"CAPE TOWN", "PORT ELIZABETH", "PRETORIA"};
String[] beverages = {"COFFEE", "TEA", "BOBA TEA"};
double[] cityTotals = new double[cities.length];

// Two-dimensional array: rows = cities, columns = beverages
double[][] sales = new double[cities.length][beverages.length];

String line = "-----------------------------------------------------------";

System.out.println(line);
System.out.println("NUMBER 1 COFFEE HUT APPLICATION");
System.out.println(line);

// Populate the arrays
for (int i = 0; i < cities.length; i++) {
for (int j = 0; j < beverages.length; j++) {
System.out.print("Enter the number of " + beverages[j]
+ " sales for " + cities[i] + ": ");
sales[i][j] = input.nextDouble();
}
}

// Report
System.out.println(line);
System.out.println("NUMBER 1 COFFEE HUT REPORT");
System.out.println(line);
System.out.printf("%-18s", "");
for (String b : beverages) {
System.out.printf("%-12s", b);
}
System.out.println();

for (int i = 0; i < cities.length; i++) {
System.out.printf("%-18s", cities[i]);
for (int j = 0; j < beverages.length; j++) {
System.out.printf("%-12.2f", sales[i][j]);
cityTotals[i] += sales[i][j];
}
System.out.println();
}

// Totals per city
System.out.println(line);
System.out.println("PRODUCT SALES TOTALS FOR EACH CITY");
System.out.println(line);

double grandTotal = 0;
for (int i = 0; i < cities.length; i++) {
System.out.printf("%-18sR%.2f%n", cities[i], cityTotals[i]);
grandTotal += cityTotals[i];
}

System.out.println();
System.out.printf("TOTAL SALES FOR CITIES: R%.2f%n", grandTotal);
System.out.println(line);

input.close();
}


