
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class RunAplicationJava {
    

    /*}import java.util.Scanner;*/
/*public class Monthly Sales {*/
public static void main(String[] args) {

Scanner input = new Scanner(System.in);

// Single-dimensional arrays
String[] cities = {
"CAPE TOWN",
"PORT ELIZABETH",
"PRETORIA"
};

String[] beverages = {
"COFFEE",
"TEA",
"BOBA TEA"
};

double[] cityTotals = new double[3];

// Two-dimensional 
double[][] sales = new double[3][3];


System.out.println("NUMBER 1 COFFEE HUT APPLICATION");
System.out.println("-----------------------------------------------");

for (int i = 0; i < cities.length; i++) {
for (int j = 0; j < beverages.length; j++) {
System.out.print(
"Enter the number of " + beverages[j]
+ " sales for " + cities[i] + ": "
);

sales[i][j] = input.nextDouble();
}
}

// Display the sales report
System.out.println("\nNUMBER 1 COFFEE HUT REPORT");
System.out.println("------------------------------------------------------------");

System.out.printf("%-18s %12s %12s %12s%n",
"CITY", "COFFEE", "TEA", "BOBA TEA");

System.out.println("------------------------------------------------------------");

for (int i = 0; i < cities.length; i++) {
System.out.printf("%-18s", cities[i]);

for (int j = 0; j < beverages.length; j++) {
System.out.printf("%12.2f", sales[i][j]);
cityTotals[i] += sales[i][j];
}

System.out.println();
}

// Display total sales for each city
System.out.println("\nPRODUCT SALES TOTALS FOR EACH CITY");
System.out.println("------------------------------------------------------------");

double grandTotal = 0;

for (int i = 0; i < cities.length; i++) {
System.out.printf("%-18s R%.2f%n",
cities[i], cityTotals[i]);

grandTotal += cityTotals[i];
}

// Display total sales for all cities
System.out.printf("%nTOTAL SALES FOR CITIES: R%.2f%n",
grandTotal);

System.out.println("------------------------------------------------------------");

input.close();
}
}





